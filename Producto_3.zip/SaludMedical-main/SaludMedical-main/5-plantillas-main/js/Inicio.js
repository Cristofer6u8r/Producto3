var btnAcc = document.getElementById("btnAccion");


btnAcc.addEventListener("click",funcionDatos);

function funcionDatos(){
    window.location.href = "cover.html";

}