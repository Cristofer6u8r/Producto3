document.getElementById('hamburger-menu').addEventListener('click', function() {
    var menu = document.getElementById('navbar-menu');
    menu.classList.toggle('active');
});